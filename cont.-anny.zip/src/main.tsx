import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { OptionsProvider } from './contexts/OptionsContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <OptionsProvider>
      <App />
    </OptionsProvider>
  </StrictMode>,
);
