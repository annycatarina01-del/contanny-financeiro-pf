import { BillPayable, CreateBillDTO, BillStatus } from "./contas-pagar.types";

export const ContasPagarService = {
  async getAll(): Promise<BillPayable[]> {
    const response = await fetch("/api/bills-payable");
    if (!response.ok) throw new Error("Erro ao buscar contas a pagar");
    return response.json();
  },

  async create(data: CreateBillDTO): Promise<{ id: string }> {
    const response = await fetch("/api/bills-payable", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao criar conta a pagar");
    return response.json();
  },

  async update(id: string, data: Partial<CreateBillDTO>): Promise<void> {
    const response = await fetch(`/api/bills-payable/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao atualizar conta a pagar");
  },

  async updateStatus(id: string, status: BillStatus, paymentDate?: string): Promise<void> {
    const response = await fetch(`/api/bills-payable/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, paymentDate }),
    });
    if (!response.ok) throw new Error("Erro ao atualizar status");
  },

  async updateStatusBulk(ids: string[], status: BillStatus, paymentDate?: string): Promise<void> {
    await Promise.all(ids.map(id => this.updateStatus(id, status, paymentDate)));
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`/api/bills-payable/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) throw new Error("Erro ao excluir conta a pagar");
  }
};
