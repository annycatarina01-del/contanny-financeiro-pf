import { AppOption, CreateOptionDTO, UpdateOptionDTO } from "./cadastros.types";

export const CadastrosService = {
  getAll: async (): Promise<AppOption[]> => {
    const res = await fetch("/api/options");
    if (!res.ok) throw new Error("Failed to fetch options");
    return res.json();
  },

  create: async (data: CreateOptionDTO): Promise<{ id: string }> => {
    const res = await fetch("/api/options", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to create option");
    return res.json();
  },

  update: async (id: string, data: UpdateOptionDTO): Promise<void> => {
    const res = await fetch(`/api/options/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to update option");
  },

  delete: async (id: string): Promise<void> => {
    const res = await fetch(`/api/options/${id}`, {
      method: "DELETE",
    });
    if (!res.ok) throw new Error("Failed to delete option");
  }
};
