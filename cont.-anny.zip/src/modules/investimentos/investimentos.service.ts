import { Investment, CreateInvestmentDTO, UpdateInvestmentDTO } from "./investimentos.types";

export const InvestimentosService = {
  async getAll(): Promise<Investment[]> {
    const response = await fetch("/api/investments");
    if (!response.ok) throw new Error("Erro ao buscar investimentos");
    return response.json();
  },

  async create(data: CreateInvestmentDTO): Promise<{ id: string }> {
    const response = await fetch("/api/investments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao criar investimento");
    return response.json();
  },

  async update(id: string, data: UpdateInvestmentDTO): Promise<void> {
    const response = await fetch(`/api/investments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao atualizar investimento");
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`/api/investments/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) throw new Error("Erro ao excluir investimento");
  },

  async redeem(id: string, amount: number, date: string): Promise<void> {
    const response = await fetch(`/api/investments/${id}/redeem`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount, date }),
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.error || "Erro ao resgatar investimento");
    }
  }
};
