import { BillReceivable, CreateReceivableDTO, ReceivableStatus } from "./contas-receber.types";

export const ContasReceberService = {
  async getAll(): Promise<BillReceivable[]> {
    const response = await fetch("/api/bills-receivable");
    if (!response.ok) throw new Error("Erro ao buscar contas a receber");
    return response.json();
  },

  async create(data: CreateReceivableDTO): Promise<{ id: string }> {
    const response = await fetch("/api/bills-receivable", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao criar conta a receber");
    return response.json();
  },

  async update(id: string, data: Partial<CreateReceivableDTO>): Promise<void> {
    const response = await fetch(`/api/bills-receivable/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao atualizar conta a receber");
  },

  async updateStatus(id: string, status: ReceivableStatus, paymentDate?: string): Promise<void> {
    const response = await fetch(`/api/bills-receivable/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, paymentDate }),
    });
    if (!response.ok) throw new Error("Erro ao atualizar status");
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`/api/bills-receivable/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) throw new Error("Erro ao excluir conta a receber");
  }
};
