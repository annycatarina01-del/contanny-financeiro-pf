import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getFinancialInsights(transactions: Transaction[]) {
  if (transactions.length === 0) return "Adicione algumas transações para receber insights personalizados.";

  const summary = transactions.map(t => ({
    type: t.type,
    amount: t.amount,
    category: t.category,
    description: t.description
  }));

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analise estas transações financeiras e forneça 3 dicas curtas e práticas em português para melhorar a saúde financeira do usuário. Seja direto e use um tom encorajador.
      
      IMPORTANTE: Sempre que citar valores monetários, formate-os estritamente como "R$ X,XX" (Real Brasileiro).
      
      Transações: ${JSON.stringify(summary)}`,
      config: {
        systemInstruction: "Você é um consultor financeiro pessoal experiente e amigável.",
      }
    });

    return response.text || "Não foi possível gerar insights no momento.";
  } catch (error) {
    console.error("Error fetching insights:", error);
    return "Erro ao conectar com a IA para gerar insights.";
  }
}
