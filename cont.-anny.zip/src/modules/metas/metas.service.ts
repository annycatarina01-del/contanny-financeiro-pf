import { MonthlyGoal, CreateGoalDTO, UpdateGoalDTO, EvaluateGoalDTO } from "./metas.types";

export const MetasService = {
  async getByMonth(month: string): Promise<MonthlyGoal | null> {
    const response = await fetch(`/api/goals/${month}`);
    if (!response.ok) throw new Error("Erro ao buscar meta do mês");
    return response.json();
  },

  async create(data: CreateGoalDTO): Promise<{ id: string }> {
    const response = await fetch("/api/goals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.error || "Erro ao criar meta");
    }
    return response.json();
  },

  async update(id: string, data: UpdateGoalDTO): Promise<void> {
    const response = await fetch(`/api/goals/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao atualizar meta");
  },

  async evaluate(id: string, data: EvaluateGoalDTO): Promise<void> {
    const response = await fetch(`/api/goals/${id}/evaluate`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Erro ao avaliar meta");
  }
};
